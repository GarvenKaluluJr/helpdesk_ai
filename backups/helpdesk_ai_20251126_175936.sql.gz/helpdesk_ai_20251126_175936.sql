--
-- PostgreSQL database dump
--

\restrict 1bbR42wzFJaOsafZyzE3c4TRNjTz1cBgMusaW5I47gIm9EUwLt1atV7j3IH7WY2

-- Dumped from database version 14.20 (Homebrew)
-- Dumped by pg_dump version 14.20 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: helpdesk
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO helpdesk;

--
-- Name: categories; Type: TABLE; Schema: public; Owner: helpdesk
--

CREATE TABLE public.categories (
    id integer NOT NULL,
    name character varying(100) NOT NULL
);


ALTER TABLE public.categories OWNER TO helpdesk;

--
-- Name: categories_id_seq; Type: SEQUENCE; Schema: public; Owner: helpdesk
--

CREATE SEQUENCE public.categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.categories_id_seq OWNER TO helpdesk;

--
-- Name: categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: helpdesk
--

ALTER SEQUENCE public.categories_id_seq OWNED BY public.categories.id;


--
-- Name: queues; Type: TABLE; Schema: public; Owner: helpdesk
--

CREATE TABLE public.queues (
    id integer NOT NULL,
    name character varying(100) NOT NULL
);


ALTER TABLE public.queues OWNER TO helpdesk;

--
-- Name: queues_id_seq; Type: SEQUENCE; Schema: public; Owner: helpdesk
--

CREATE SEQUENCE public.queues_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.queues_id_seq OWNER TO helpdesk;

--
-- Name: queues_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: helpdesk
--

ALTER SEQUENCE public.queues_id_seq OWNED BY public.queues.id;


--
-- Name: ticket_history; Type: TABLE; Schema: public; Owner: helpdesk
--

CREATE TABLE public.ticket_history (
    id integer NOT NULL,
    ticket_id integer NOT NULL,
    field character varying(100) NOT NULL,
    old_value text,
    new_value text NOT NULL,
    changed_by integer,
    changed_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.ticket_history OWNER TO helpdesk;

--
-- Name: ticket_history_id_seq; Type: SEQUENCE; Schema: public; Owner: helpdesk
--

CREATE SEQUENCE public.ticket_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ticket_history_id_seq OWNER TO helpdesk;

--
-- Name: ticket_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: helpdesk
--

ALTER SEQUENCE public.ticket_history_id_seq OWNED BY public.ticket_history.id;


--
-- Name: tickets; Type: TABLE; Schema: public; Owner: helpdesk
--

CREATE TABLE public.tickets (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    subject character varying(255) NOT NULL,
    body text NOT NULL,
    category_pred character varying(100),
    category_final character varying(100),
    priority_pred character varying(50),
    priority_final character varying(50),
    queue character varying(100),
    status character varying(50) DEFAULT 'new'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    confidence double precision
);


ALTER TABLE public.tickets OWNER TO helpdesk;

--
-- Name: tickets_id_seq; Type: SEQUENCE; Schema: public; Owner: helpdesk
--

CREATE SEQUENCE public.tickets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tickets_id_seq OWNER TO helpdesk;

--
-- Name: tickets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: helpdesk
--

ALTER SEQUENCE public.tickets_id_seq OWNED BY public.tickets.id;


--
-- Name: training_runs; Type: TABLE; Schema: public; Owner: helpdesk
--

CREATE TABLE public.training_runs (
    id integer NOT NULL,
    run_at timestamp with time zone DEFAULT now() NOT NULL,
    accuracy_ml double precision,
    macro_f1_ml double precision,
    accuracy_baseline double precision,
    macro_f1_baseline double precision,
    report_json text
);


ALTER TABLE public.training_runs OWNER TO helpdesk;

--
-- Name: training_runs_id_seq; Type: SEQUENCE; Schema: public; Owner: helpdesk
--

CREATE SEQUENCE public.training_runs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.training_runs_id_seq OWNER TO helpdesk;

--
-- Name: training_runs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: helpdesk
--

ALTER SEQUENCE public.training_runs_id_seq OWNED BY public.training_runs.id;


--
-- Name: training_samples; Type: TABLE; Schema: public; Owner: helpdesk
--

CREATE TABLE public.training_samples (
    id integer NOT NULL,
    subject text NOT NULL,
    body text NOT NULL,
    true_category text NOT NULL,
    true_priority text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.training_samples OWNER TO helpdesk;

--
-- Name: training_samples_id_seq; Type: SEQUENCE; Schema: public; Owner: helpdesk
--

CREATE SEQUENCE public.training_samples_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.training_samples_id_seq OWNER TO helpdesk;

--
-- Name: training_samples_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: helpdesk
--

ALTER SEQUENCE public.training_samples_id_seq OWNED BY public.training_samples.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: helpdesk
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(100) NOT NULL,
    password_hash character varying(255) NOT NULL,
    role character varying(50) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.users OWNER TO helpdesk;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: helpdesk
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO helpdesk;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: helpdesk
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: categories id; Type: DEFAULT; Schema: public; Owner: helpdesk
--

ALTER TABLE ONLY public.categories ALTER COLUMN id SET DEFAULT nextval('public.categories_id_seq'::regclass);


--
-- Name: queues id; Type: DEFAULT; Schema: public; Owner: helpdesk
--

ALTER TABLE ONLY public.queues ALTER COLUMN id SET DEFAULT nextval('public.queues_id_seq'::regclass);


--
-- Name: ticket_history id; Type: DEFAULT; Schema: public; Owner: helpdesk
--

ALTER TABLE ONLY public.ticket_history ALTER COLUMN id SET DEFAULT nextval('public.ticket_history_id_seq'::regclass);


--
-- Name: tickets id; Type: DEFAULT; Schema: public; Owner: helpdesk
--

ALTER TABLE ONLY public.tickets ALTER COLUMN id SET DEFAULT nextval('public.tickets_id_seq'::regclass);


--
-- Name: training_runs id; Type: DEFAULT; Schema: public; Owner: helpdesk
--

ALTER TABLE ONLY public.training_runs ALTER COLUMN id SET DEFAULT nextval('public.training_runs_id_seq'::regclass);


--
-- Name: training_samples id; Type: DEFAULT; Schema: public; Owner: helpdesk
--

ALTER TABLE ONLY public.training_samples ALTER COLUMN id SET DEFAULT nextval('public.training_samples_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: helpdesk
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: helpdesk
--

COPY public.alembic_version (version_num) FROM stdin;
169bbdc1de42
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: helpdesk
--

COPY public.categories (id, name) FROM stdin;
\.


--
-- Data for Name: queues; Type: TABLE DATA; Schema: public; Owner: helpdesk
--

COPY public.queues (id, name) FROM stdin;
\.


--
-- Data for Name: ticket_history; Type: TABLE DATA; Schema: public; Owner: helpdesk
--

COPY public.ticket_history (id, ticket_id, field, old_value, new_value, changed_by, changed_at) FROM stdin;
1	12	category_final		General	1	2025-11-25 21:41:00.14953+03
2	12	priority_final		low	1	2025-11-25 21:41:00.14953+03
3	12	queue		12	1	2025-11-25 21:41:00.14953+03
4	11	category_final		General	1	2025-11-25 21:43:27.39806+03
5	11	priority_final		low	1	2025-11-25 21:43:27.39806+03
6	11	queue		11	1	2025-11-25 21:43:27.39806+03
7	10	category_final		Financy	1	2025-11-26 01:37:19.672136+03
8	10	priority_final		High	1	2025-11-26 01:37:19.672136+03
9	10	queue		10	1	2025-11-26 01:37:19.672136+03
10	9	category_final		Administration	1	2025-11-26 01:38:40.011237+03
11	9	priority_final		High	1	2025-11-26 01:38:40.011237+03
12	9	queue		9	1	2025-11-26 01:38:40.011237+03
13	8	category_final		Financy	1	2025-11-26 01:39:00.061888+03
14	8	priority_final		High	1	2025-11-26 01:39:00.061888+03
15	8	queue		9	1	2025-11-26 01:39:00.061888+03
16	7	category_final		Account	1	2025-11-26 01:39:29.953934+03
17	7	priority_final		Medium	1	2025-11-26 01:39:29.953934+03
18	7	queue		7	1	2025-11-26 01:39:29.953934+03
19	6	category_final		Account	1	2025-11-26 01:39:49.18918+03
20	6	priority_final		Medium	1	2025-11-26 01:39:49.18918+03
21	6	queue		6	1	2025-11-26 01:39:49.18918+03
22	5	category_final		Account	1	2025-11-26 01:40:09.576494+03
23	5	priority_final		low	1	2025-11-26 01:40:09.576494+03
24	5	queue		5	1	2025-11-26 01:40:09.576494+03
25	4	category_final		Account	1	2025-11-26 01:41:25.427294+03
26	4	priority_final		High	1	2025-11-26 01:41:25.427294+03
27	4	queue		4	1	2025-11-26 01:41:25.427294+03
28	2	category_final		General	1	2025-11-26 01:41:56.533583+03
29	2	priority_final		low	1	2025-11-26 01:41:56.533583+03
30	2	queue		2	1	2025-11-26 01:41:56.533583+03
31	1	category_final		General	1	2025-11-26 01:42:12.517378+03
32	1	priority_final		low	1	2025-11-26 01:42:12.517378+03
33	1	queue		1	1	2025-11-26 01:42:12.517378+03
34	3	category_final		General	1	2025-11-26 01:42:29.716584+03
35	3	priority_final		low	1	2025-11-26 01:42:29.716584+03
36	3	queue		3	1	2025-11-26 01:42:29.716584+03
37	14	priority_final		Medium	1	2025-11-26 02:23:56.641356+03
38	14	queue		14	1	2025-11-26 02:23:56.641356+03
39	13	category_final		Administration	1	2025-11-26 02:24:21.606272+03
40	13	priority_final		low	1	2025-11-26 02:24:21.606272+03
41	13	queue		13	1	2025-11-26 02:24:21.606272+03
42	15	priority_final		low	1	2025-11-26 02:31:20.882027+03
43	15	queue		15	1	2025-11-26 02:31:20.882027+03
44	16	queue		16	1	2025-11-26 03:36:11.434688+03
45	17	queue		17	1	2025-11-26 03:36:23.693126+03
\.


--
-- Data for Name: tickets; Type: TABLE DATA; Schema: public; Owner: helpdesk
--

COPY public.tickets (id, name, email, subject, body, category_pred, category_final, priority_pred, priority_final, queue, status, created_at, updated_at, confidence) FROM stdin;
12	wat	wat@gmail.com	Nothing really 	What a joke man!\r\n	\N	General	\N	low	12	new	2025-11-25 19:40:06.387658+03	2025-11-25 21:41:00.14953+03	\N
11	Eli	eLI@gmail.com	School	How about that man, we need help here like it was never addressed around here.	\N	General	\N	low	11	new	2025-11-25 19:31:15.182308+03	2025-11-25 21:43:27.39806+03	\N
10	misheck	liks@gmail.com	Money isn't beeing recieved to my account here	I have been waiting for my money, whats with the school issue here	\N	Financy	\N	High	10	new	2025-11-25 18:01:47.763886+03	2025-11-26 01:37:19.672136+03	\N
9	Junior	Yala@gmail.com	School issue	I did not clear all my courses so I need help with renegotiating everything here. 	\N	Administration	\N	High	9	new	2025-11-25 17:48:07.62081+03	2025-11-26 01:38:40.011237+03	\N
8	Giz	gizgates@gmail.com	I haven't received my money yet	I have been waiting for my stipend for quiet some months now none the less I haven't recieved my money yet.	\N	Financy	\N	High	9	new	2025-11-25 17:43:25.954704+03	2025-11-26 01:39:00.061888+03	\N
7	Garven	garvenkalulu2000@gmail.com	I can't log into my account.	Nothing really works with this whole thing you know.	\N	Account	\N	Medium	7	new	2025-11-25 17:40:19.804446+03	2025-11-26 01:39:29.953934+03	\N
6	garven	garvenkalulu2000@gmail.com	I can't log into my account.	I have been trying for quiet some time to log into my account on openedu I need to clear some clourses.	\N	Account	\N	Medium	6	new	2025-11-25 17:39:45.127795+03	2025-11-26 01:39:49.18918+03	\N
5	Garven Kalulu	garvenkalulu2000@gmail.com	Cannot log into LMS	I get an error when I try to log in.	\N	Account	\N	low	5	new	2025-11-25 16:07:40.403633+03	2025-11-26 01:40:09.576494+03	\N
4	Garven Kalulu	garvenkalulu2000@gmail.com	Cannot log into LMS	I get an error when I try to log in.	\N	Account	\N	High	4	new	2025-11-25 16:03:10.589866+03	2025-11-26 01:41:25.427294+03	\N
2	string	user@example.com	string	string	\N	General	\N	low	2	new	2025-11-25 15:57:04.061706+03	2025-11-26 01:41:56.533583+03	\N
1	string	user@example.com	string	string	\N	General	\N	low	1	new	2025-11-25 15:57:01.664584+03	2025-11-26 01:42:12.517378+03	\N
3	string	user@example.com	string	string	\N	General	\N	low	3	new	2025-11-25 15:57:25.24991+03	2025-11-26 01:42:29.716584+03	\N
14	prosper 	prosper@gmail.com	Can't log in	I have been trying over and over to log in my dl account however I can't get through to it	Account	Account	\N	Medium	14	new	2025-11-26 02:20:38.385902+03	2025-11-26 02:23:56.641356+03	0.5334063486185876
13	giz	giz@gmail.com	School credit 	I never got graded for the work I submitted. 	\N	Administration	\N	low	13	new	2025-11-26 01:56:06.585714+03	2025-11-26 02:24:21.606272+03	\N
15	Krytic	krytic@gmail.com	Inquiring about admission	I need to know about the adiminission process especially when it will commmerce?	General	General	\N	low	15	new	2025-11-26 02:31:03.0203+03	2025-11-26 02:31:20.882027+03	0.37564941283419157
16	king	king@example.com	Can't log in	I can't get some of my courses from the site.	Account	Account	high	high	16	new	2025-11-26 03:33:21.913644+03	2025-11-26 03:36:11.434688+03	0.4348622091214988
17	kay	kay@gmail.com	money issue here	I can't receive my stipend and it has been pretty hard for me here I need this money for my food. 	General	General	low	low	17	new	2025-11-26 03:34:39.949668+03	2025-11-26 03:36:23.693126+03	0.33205300834953716
18	chilling	chilling@gmail.com	Can't log in	Can't get into my account, its frustrating buddy!	Account	Account	Medium	Medium	IT	new	2025-11-26 04:35:12.32833+03	2025-11-26 04:35:12.32833+03	0.545823154163798
19	mike	mike@gmail.com	School issue	I have been finding it hard to find some of the text books	General	General	Low	Low	General	new	2025-11-26 04:38:18.945441+03	2025-11-26 04:38:18.945441+03	0.36542749974734956
20	manin	manin@gmail.com	Can't log in	can't get through the cabinet	Account	Account	Medium	Medium	IT	new	2025-11-26 05:01:05.155115+03	2025-11-26 05:01:05.155115+03	0.5395589645244503
21	Garven$	garvenkalulu2000@gmail.com	Can't log in	can't log in	Account	Account	Medium	Medium	IT	new	2025-11-26 14:29:12.347592+03	2025-11-26 14:29:12.347592+03	0.5395589645244503
22	jay	jay@gmail.com	Can't log in to LMS	I can't log into the university LMS, it keeps saying my password is incorrect.	Account	Account	Medium	Medium	IT	new	2025-11-26 14:44:02.542037+03	2025-11-26 14:44:02.542037+03	0.5409911327124863
23	walter whyte	walter@gmail.com	School issue	My school man 	Financy	Financy	Medium	Medium	Finance	new	2025-11-26 15:42:27.817742+03	2025-11-26 15:42:27.817742+03	0.26638846416991113
24	wytte	wytte@gmail.com	Can't log in	Can't log in	Account	Account	Medium	Medium	IT	new	2025-11-26 15:43:20.838172+03	2025-11-26 15:43:20.838172+03	0.26770168428570745
25	Garven	garvenkalulu2000@gmail.com	Can't log in	Can't log in	Account	Account	Medium	Medium	IT	new	2025-11-26 17:30:10.383649+03	2025-11-26 17:30:10.383649+03	0.26770168428570745
\.


--
-- Data for Name: training_runs; Type: TABLE DATA; Schema: public; Owner: helpdesk
--

COPY public.training_runs (id, run_at, accuracy_ml, macro_f1_ml, accuracy_baseline, macro_f1_baseline, report_json) FROM stdin;
1	2025-11-26 14:42:07.66806+03	0	0	0.6	0.5	{"ml": {"accuracy": 0.0, "macro_f1": 0.0, "report": {"Account": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 1.0}, "Administration": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 1.0}, "Financy": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 1.0}, "General": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 1.0}, "Technical": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 1.0}, "accuracy": 0.0, "macro avg": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 5.0}, "weighted avg": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 5.0}}}, "baseline": {"accuracy": 0.6, "macro_f1": 0.5, "report": {"Account": {"precision": 1.0, "recall": 1.0, "f1-score": 1.0, "support": 1.0}, "Administration": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 1.0}, "Financy": {"precision": 1.0, "recall": 1.0, "f1-score": 1.0, "support": 1.0}, "General": {"precision": 0.3333333333333333, "recall": 1.0, "f1-score": 0.5, "support": 1.0}, "Technical": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 1.0}, "accuracy": 0.6, "macro avg": {"precision": 0.4666666666666667, "recall": 0.6, "f1-score": 0.5, "support": 5.0}, "weighted avg": {"precision": 0.4666666666666667, "recall": 0.6, "f1-score": 0.5, "support": 5.0}}}}
2	2025-11-26 14:51:40.672296+03	0	0	0.6	0.5	{"ml": {"accuracy": 0.0, "macro_f1": 0.0, "report": {"Account": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 1.0}, "Administration": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 1.0}, "Financy": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 1.0}, "General": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 1.0}, "Technical": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 1.0}, "accuracy": 0.0, "macro avg": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 5.0}, "weighted avg": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 5.0}}}, "baseline": {"accuracy": 0.6, "macro_f1": 0.5, "report": {"Account": {"precision": 1.0, "recall": 1.0, "f1-score": 1.0, "support": 1.0}, "Administration": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 1.0}, "Financy": {"precision": 1.0, "recall": 1.0, "f1-score": 1.0, "support": 1.0}, "General": {"precision": 0.3333333333333333, "recall": 1.0, "f1-score": 0.5, "support": 1.0}, "Technical": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 1.0}, "accuracy": 0.6, "macro avg": {"precision": 0.4666666666666667, "recall": 0.6, "f1-score": 0.5, "support": 5.0}, "weighted avg": {"precision": 0.4666666666666667, "recall": 0.6, "f1-score": 0.5, "support": 5.0}}}}
3	2025-11-26 15:13:52.87338+03	0	0	0.6	0.5	{"ml": {"accuracy": 0.0, "macro_f1": 0.0, "report": {"Account": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 1.0}, "Administration": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 1.0}, "Financy": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 1.0}, "General": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 1.0}, "Technical": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 1.0}, "accuracy": 0.0, "macro avg": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 5.0}, "weighted avg": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 5.0}}}, "baseline": {"accuracy": 0.6, "macro_f1": 0.5, "report": {"Account": {"precision": 1.0, "recall": 1.0, "f1-score": 1.0, "support": 1.0}, "Administration": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 1.0}, "Financy": {"precision": 1.0, "recall": 1.0, "f1-score": 1.0, "support": 1.0}, "General": {"precision": 0.3333333333333333, "recall": 1.0, "f1-score": 0.5, "support": 1.0}, "Technical": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 1.0}, "accuracy": 0.6, "macro avg": {"precision": 0.4666666666666667, "recall": 0.6, "f1-score": 0.5, "support": 5.0}, "weighted avg": {"precision": 0.4666666666666667, "recall": 0.6, "f1-score": 0.5, "support": 5.0}}}}
4	2025-11-26 15:20:05.812599+03	0	0	0.6	0.5	{"ml": {"accuracy": 0.0, "macro_f1": 0.0, "report": {"Account": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 1.0}, "Administration": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 1.0}, "Financy": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 1.0}, "General": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 1.0}, "Technical": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 1.0}, "accuracy": 0.0, "macro avg": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 5.0}, "weighted avg": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 5.0}}}, "baseline": {"accuracy": 0.6, "macro_f1": 0.5, "report": {"Account": {"precision": 1.0, "recall": 1.0, "f1-score": 1.0, "support": 1.0}, "Administration": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 1.0}, "Financy": {"precision": 1.0, "recall": 1.0, "f1-score": 1.0, "support": 1.0}, "General": {"precision": 0.3333333333333333, "recall": 1.0, "f1-score": 0.5, "support": 1.0}, "Technical": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 1.0}, "accuracy": 0.6, "macro avg": {"precision": 0.4666666666666667, "recall": 0.6, "f1-score": 0.5, "support": 5.0}, "weighted avg": {"precision": 0.4666666666666667, "recall": 0.6, "f1-score": 0.5, "support": 5.0}}}}
5	2025-11-26 15:20:29.589466+03	0	0	0.6	0.5	{"ml": {"accuracy": 0.0, "macro_f1": 0.0, "report": {"Account": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 1.0}, "Administration": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 1.0}, "Financy": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 1.0}, "General": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 1.0}, "Technical": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 1.0}, "accuracy": 0.0, "macro avg": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 5.0}, "weighted avg": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 5.0}}}, "baseline": {"accuracy": 0.6, "macro_f1": 0.5, "report": {"Account": {"precision": 1.0, "recall": 1.0, "f1-score": 1.0, "support": 1.0}, "Administration": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 1.0}, "Financy": {"precision": 1.0, "recall": 1.0, "f1-score": 1.0, "support": 1.0}, "General": {"precision": 0.3333333333333333, "recall": 1.0, "f1-score": 0.5, "support": 1.0}, "Technical": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 1.0}, "accuracy": 0.6, "macro avg": {"precision": 0.4666666666666667, "recall": 0.6, "f1-score": 0.5, "support": 5.0}, "weighted avg": {"precision": 0.4666666666666667, "recall": 0.6, "f1-score": 0.5, "support": 5.0}}}}
6	2025-11-26 15:40:28.203155+03	0	0	0.6	0.5333333333333333	{"ml": {"accuracy": 0.0, "macro_f1": 0.0, "report": {"Account": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 1.0}, "Administration": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 1.0}, "Financy": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 1.0}, "General": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 1.0}, "Technical": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 1.0}, "accuracy": 0.0, "macro avg": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 5.0}, "weighted avg": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 5.0}}}, "baseline": {"accuracy": 0.6, "macro_f1": 0.5333333333333333, "report": {"Account": {"precision": 1.0, "recall": 1.0, "f1-score": 1.0, "support": 1.0}, "Administration": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 1.0}, "Financy": {"precision": 1.0, "recall": 1.0, "f1-score": 1.0, "support": 1.0}, "General": {"precision": 0.5, "recall": 1.0, "f1-score": 0.6666666666666666, "support": 1.0}, "Technical": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 1.0}, "accuracy": 0.6, "macro avg": {"precision": 0.5, "recall": 0.6, "f1-score": 0.5333333333333333, "support": 5.0}, "weighted avg": {"precision": 0.5, "recall": 0.6, "f1-score": 0.5333333333333333, "support": 5.0}}}}
7	2025-11-26 15:41:36.539649+03	0	0	0.6	0.5333333333333333	{"ml": {"accuracy": 0.0, "macro_f1": 0.0, "report": {"Account": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 1.0}, "Administration": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 1.0}, "Financy": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 1.0}, "General": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 1.0}, "Technical": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 1.0}, "accuracy": 0.0, "macro avg": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 5.0}, "weighted avg": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 5.0}}}, "baseline": {"accuracy": 0.6, "macro_f1": 0.5333333333333333, "report": {"Account": {"precision": 1.0, "recall": 1.0, "f1-score": 1.0, "support": 1.0}, "Administration": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 1.0}, "Financy": {"precision": 1.0, "recall": 1.0, "f1-score": 1.0, "support": 1.0}, "General": {"precision": 0.5, "recall": 1.0, "f1-score": 0.6666666666666666, "support": 1.0}, "Technical": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 1.0}, "accuracy": 0.6, "macro avg": {"precision": 0.5, "recall": 0.6, "f1-score": 0.5333333333333333, "support": 5.0}, "weighted avg": {"precision": 0.5, "recall": 0.6, "f1-score": 0.5333333333333333, "support": 5.0}}}}
8	2025-11-26 17:30:37.322235+03	0	0	0.6	0.5333333333333333	{"ml": {"accuracy": 0.0, "macro_f1": 0.0, "report": {"Account": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 1.0}, "Administration": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 1.0}, "Financy": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 1.0}, "General": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 1.0}, "Technical": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 1.0}, "accuracy": 0.0, "macro avg": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 5.0}, "weighted avg": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 5.0}}}, "baseline": {"accuracy": 0.6, "macro_f1": 0.5333333333333333, "report": {"Account": {"precision": 1.0, "recall": 1.0, "f1-score": 1.0, "support": 1.0}, "Administration": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 1.0}, "Financy": {"precision": 1.0, "recall": 1.0, "f1-score": 1.0, "support": 1.0}, "General": {"precision": 0.5, "recall": 1.0, "f1-score": 0.6666666666666666, "support": 1.0}, "Technical": {"precision": 0.0, "recall": 0.0, "f1-score": 0.0, "support": 1.0}, "accuracy": 0.6, "macro avg": {"precision": 0.5, "recall": 0.6, "f1-score": 0.5333333333333333, "support": 5.0}, "weighted avg": {"precision": 0.5, "recall": 0.6, "f1-score": 0.5333333333333333, "support": 5.0}}}}
\.


--
-- Data for Name: training_samples; Type: TABLE DATA; Schema: public; Owner: helpdesk
--

COPY public.training_samples (id, subject, body, true_category, true_priority, created_at) FROM stdin;
1	Can't log in to LMS	I can't log into the university LMS, it keeps saying my password is incorrect.	Account	high	2025-11-26 14:41:59.15203+03
2	Password reset not working	I requested a password reset email but I never receive it.	Account	medium	2025-11-26 14:41:59.15203+03
3	Email account locked	My university email says the account is locked after too many attempts.	Account	high	2025-11-26 14:41:59.15203+03
4	Money missing from my account	My tuition payment was taken from my bank but it does not show up in my university finance account.	Financy	high	2025-11-26 14:41:59.15203+03
5	Scholarship payment delay	My scholarship money is usually paid by the 5th but this month it is still not in my account.	Financy	medium	2025-11-26 14:41:59.15203+03
6	Incorrect invoice	The invoice for my dormitory includes an extra fee that I never agreed to.	Financy	medium	2025-11-26 14:41:59.15203+03
7	Problem with course registration	The registration system shows that the course is full even though the teacher said there are free places.	Administration	medium	2025-11-26 14:41:59.15203+03
8	Request to change study group	I would like to move from group 12101 to 12103 due to schedule conflicts.	Administration	low	2025-11-26 14:41:59.15203+03
9	Question about examination rules	Can you explain how retake exams work if I failed a subject twice?	Administration	low	2025-11-26 14:41:59.15203+03
10	Wifi not working in dorm	Since yesterday evening the dorm wifi does not connect on any of my devices.	Technical	high	2025-11-26 14:41:59.15203+03
11	Projector problem in classroom	The projector in room 312 turns on but there is no signal from the HDMI input.	Technical	medium	2025-11-26 14:41:59.15203+03
12	VPN connection issue	I cannot connect to the university VPN from home, it says authentication failed.	Technical	medium	2025-11-26 14:41:59.15203+03
13	Library opening hours	What are the library opening hours during the exam session?	General	low	2025-11-26 14:41:59.15203+03
14	Sports center membership	How can I get a student discount for the university sports center?	General	low	2025-11-26 14:41:59.15203+03
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: helpdesk
--

COPY public.users (id, username, password_hash, role, created_at, updated_at) FROM stdin;
1	admin	$pbkdf2-sha256$29000$1zqnFCKEMIZQKqWUUiqF0A$kv.xH2KeavDb3oyxzGoFj7Lu4z.rE6xgH6cD3TsZmd8	admin	2025-11-25 19:29:07.250127+03	2025-11-25 19:29:07.250127+03
\.


--
-- Name: categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: helpdesk
--

SELECT pg_catalog.setval('public.categories_id_seq', 1, false);


--
-- Name: queues_id_seq; Type: SEQUENCE SET; Schema: public; Owner: helpdesk
--

SELECT pg_catalog.setval('public.queues_id_seq', 1, false);


--
-- Name: ticket_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: helpdesk
--

SELECT pg_catalog.setval('public.ticket_history_id_seq', 45, true);


--
-- Name: tickets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: helpdesk
--

SELECT pg_catalog.setval('public.tickets_id_seq', 25, true);


--
-- Name: training_runs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: helpdesk
--

SELECT pg_catalog.setval('public.training_runs_id_seq', 8, true);


--
-- Name: training_samples_id_seq; Type: SEQUENCE SET; Schema: public; Owner: helpdesk
--

SELECT pg_catalog.setval('public.training_samples_id_seq', 14, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: helpdesk
--

SELECT pg_catalog.setval('public.users_id_seq', 4, true);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: helpdesk
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: categories categories_name_key; Type: CONSTRAINT; Schema: public; Owner: helpdesk
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_name_key UNIQUE (name);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: helpdesk
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: queues queues_name_key; Type: CONSTRAINT; Schema: public; Owner: helpdesk
--

ALTER TABLE ONLY public.queues
    ADD CONSTRAINT queues_name_key UNIQUE (name);


--
-- Name: queues queues_pkey; Type: CONSTRAINT; Schema: public; Owner: helpdesk
--

ALTER TABLE ONLY public.queues
    ADD CONSTRAINT queues_pkey PRIMARY KEY (id);


--
-- Name: ticket_history ticket_history_pkey; Type: CONSTRAINT; Schema: public; Owner: helpdesk
--

ALTER TABLE ONLY public.ticket_history
    ADD CONSTRAINT ticket_history_pkey PRIMARY KEY (id);


--
-- Name: tickets tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: helpdesk
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_pkey PRIMARY KEY (id);


--
-- Name: training_runs training_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: helpdesk
--

ALTER TABLE ONLY public.training_runs
    ADD CONSTRAINT training_runs_pkey PRIMARY KEY (id);


--
-- Name: training_samples training_samples_pkey; Type: CONSTRAINT; Schema: public; Owner: helpdesk
--

ALTER TABLE ONLY public.training_samples
    ADD CONSTRAINT training_samples_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: helpdesk
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: helpdesk
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: ticket_history ticket_history_changed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: helpdesk
--

ALTER TABLE ONLY public.ticket_history
    ADD CONSTRAINT ticket_history_changed_by_fkey FOREIGN KEY (changed_by) REFERENCES public.users(id);


--
-- Name: ticket_history ticket_history_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: helpdesk
--

ALTER TABLE ONLY public.ticket_history
    ADD CONSTRAINT ticket_history_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.tickets(id);


--
-- PostgreSQL database dump complete
--

\unrestrict 1bbR42wzFJaOsafZyzE3c4TRNjTz1cBgMusaW5I47gIm9EUwLt1atV7j3IH7WY2

